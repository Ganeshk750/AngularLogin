import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-ip-address',
  templateUrl: './ip-address.component.html',
  styleUrls: ['./ip-address.component.css']
})
export class IpAddressComponent implements OnInit {

  checkForm: FormGroup;
  digits: number;

  constructor(private fb: FormBuilder) { }

  ngOnInit() {
    this.checkForm = this.fb.group({
      address: ['', [Validators.required,
      Validators.pattern(/^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/)]]
    });
  }

  get address() {
    return this.checkForm.get('address');
  }


  checkingIp() {
    let str = this.checkForm.controls.address.value;
    this.digits = str.split('.', 3);
    if (this.digits[0] >= 1 && this.digits[0] <= 126)
      alert("Class: A");
    else if (this.digits[0] >= 128 && this.digits[0] <= 191)
      alert("Class: B");
    else if (this.digits[0] >= 192 && this.digits[0] < 223)
      alert("Class: C");
    else if (this.digits[0] >= 224 && this.digits[0] <= 239)
      alert("Class: D");
    else
      alert("Class: E");

  }


}
